export const groups = [
  {
    title: 'אלעד',
    children: [
      {
        title: 'הבוס'
      },
      {
        title: 'העייף',
        children: [
          { title: 'מאוד' }
        ]
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  }
];

export const tableData = {
  users: [
    { name: 'אלעד', role: 'טיפש', isGroupAdmin: true }, { name: 'יונתן', role: 'חכם', isAdmin: false },
    { name: 'יונתן', role: 'חכם', isAdmin: false }, { name: 'יונתן', role: 'חכם', isAdmin: false },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true },
    { name: 'יונתן', role: 'היררכיקה', isAdmin: false }, { name: 'יונתן', role: 'היררכיקה', isAdmin: true }
  ],
  headerCols: ['שם', 'תפקיד'],
  dataFields: ['name', 'role']

};

