import UsersTable from './UsersTable';
export default UsersTable;