import Dialog from './ProfileDialog';

export default Dialog;