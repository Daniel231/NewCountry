import styled from 'styled-components';

export const ActionText = styled.span`
    fomt-weight: ${props => props.bold ? 'bold' : 'normal'};
    color: white;
`;