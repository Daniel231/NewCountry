import styled from 'styled-components';

export const DetailField = styled.div`
    display: inline-flex;
    color: #7B8A8D;
    font-size: 12px;
    width: 29%;
`;

export const Normal = styled.div`
    display: inline-block;
    font-size: 12px;
`;