import ExtendedDetails from './ExtendedUserDetails';

export default ExtendedDetails;