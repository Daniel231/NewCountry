import UsersGrid from './UsersGrid';
export default UsersGrid;