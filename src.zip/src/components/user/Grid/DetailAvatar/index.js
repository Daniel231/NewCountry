import DetailAvatar from './DetailAvatar';

export default DetailAvatar;
