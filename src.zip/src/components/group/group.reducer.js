const groups = [
  {
    title: 'אלעד',
    children: [
      {
        title: 'הבוס'
      },
      {
        title: 'העייף',
        children: [
          { title: 'מאוד' }
        ]
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  },
  {
    title: 'יונתן',
    children: [
      {
        title: 'האפורי'
      }
    ]
  }
];

export default function(state = groups) {
  return state;
}
